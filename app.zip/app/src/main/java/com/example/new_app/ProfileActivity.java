package com.example.new_app;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class ProfileActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        // Initialize UI components
        @SuppressLint({"MissingInflatedId", "LocalSuppress"}) TextView tvLastDisease = findViewById(R.id.tvLastDisease);
        @SuppressLint({"MissingInflatedId", "LocalSuppress"}) TextView tvLastSuggestion = findViewById(R.id.tvLastSuggestion);
        @SuppressLint({"MissingInflatedId", "LocalSuppress"}) Button logout=findViewById(R.id.logoutbtn);
        // Retrieve saved results from SharedPreferences
        SharedPreferences sharedPreferences = getSharedPreferences("PredictionResults", MODE_PRIVATE);
        String lastDisease = sharedPreferences.getString("last_disease", "No data available");
        String lastSuggestion = sharedPreferences.getString("last_suggestion", "No suggestions available");

        // Set the retrieved data in the TextViews
        tvLastDisease.setText("Last Detected Disease: " + lastDisease);
        tvLastSuggestion.setText("Last Suggestion: " + lastSuggestion);

        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ProfileActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });
    }
}
