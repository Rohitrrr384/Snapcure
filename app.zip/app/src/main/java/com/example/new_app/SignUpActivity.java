package com.example.new_app;


import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.new_app.R;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class SignUpActivity extends AppCompatActivity {

    private EditText usernameEditText, passwordEditText, emailEditText;
    private Button registerButton;

    // Backend URL
    private static final String BASE_URL = "http://192.168.96.166:5005"; // Replace with your backend URL
    private static final String REGISTER_ENDPOINT = "/register";

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        // Initialize UI components
        usernameEditText = findViewById(R.id.usernameEditText);
        passwordEditText = findViewById(R.id.passwordEditText);
        emailEditText = findViewById(R.id.emailEditText);
        registerButton = findViewById(R.id.registerButton);

        // Handle Register Button Click
        registerButton.setOnClickListener(view -> handleRegister());
    }

    private void handleRegister() {
        String username = usernameEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString().trim();
        String email = emailEditText.getText().toString().trim();

        // Validate input fields
        if (username.isEmpty() || password.isEmpty() || email.isEmpty()) {
            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        // Create JSON payload for registration
        JSONObject registerPayload = new JSONObject();
        try {
            registerPayload.put("username", username);
            registerPayload.put("password", password);
            registerPayload.put("email", email);
        } catch (JSONException e) {
            e.printStackTrace();
            Toast.makeText(this, "Error creating registration payload", Toast.LENGTH_SHORT).show();
            return;
        }

        // Send registration request to backend
        sendRegisterRequest(registerPayload);
    }

    private void sendRegisterRequest(JSONObject registerPayload) {
        OkHttpClient client = new OkHttpClient();

        // Request body
        MediaType JSON = MediaType.parse("application/json; charset=utf-8");
        RequestBody body = RequestBody.create(registerPayload.toString(), JSON);

        // Request object
        Request request = new Request.Builder()
                .url(BASE_URL + REGISTER_ENDPOINT)
                .post(body)
                .build();

        // Execute the request
        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                runOnUiThread(() -> Toast.makeText(SignUpActivity.this, "Registration failed: " + e.getMessage(), Toast.LENGTH_SHORT).show());
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (response.isSuccessful()) {
                    runOnUiThread(() -> {
                        Toast.makeText(SignUpActivity.this, "Registration successful! Please log in.", Toast.LENGTH_SHORT).show();
                        finish(); // Close the RegisterActivity and return to MainActivity
                    });
                } else {
                    runOnUiThread(() -> Toast.makeText(SignUpActivity.this, "Registration failed. Try again.", Toast.LENGTH_SHORT).show());
                }
            }
        });
    }
}

