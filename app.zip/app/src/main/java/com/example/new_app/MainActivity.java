package com.example.new_app;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private TextView typewriterDescription;
    private Button loginSignUpButton;
    private String fullText = "    SnapCure is an innovative solution designed to help farmers identify and manage plant diseases efficiently. By leveraging machine learning, the system analyzes images of plant leaves to detect diseases and provides real-time treatment recommendations through a user-friendly mobile application.";
    private int index = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        typewriterDescription = findViewById(R.id.typewriterDescription);
        loginSignUpButton = findViewById(R.id.loginSignUpButton);

        startTypingAnimation();

        loginSignUpButton.setOnClickListener(v -> {
            // Navigate to LoginActivity
            Intent intent = new Intent(MainActivity.this, LoginActivity.class);
            startActivity(intent);
        });
    }

    private void startTypingAnimation() {
        Handler handler = new Handler();
        Runnable runnable = new Runnable() {
            @Override
            public void run() {
                if (index < fullText.length()) {
                    typewriterDescription.append(String.valueOf(fullText.charAt(index)));
                    index++;
                    handler.postDelayed(this, 50); // Typing speed
                }
            }
        };
        handler.post(runnable);
    }
}
