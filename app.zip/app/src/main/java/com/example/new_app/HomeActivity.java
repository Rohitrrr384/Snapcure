package com.example.new_app;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import org.json.JSONObject;

public class HomeActivity extends AppCompatActivity {

    private static final String API_URL = "http://192.168.96.166:5001/predict"; // Replace with actual API URL
    private static final int GALLERY_REQUEST_CODE = 100;

    private ImageView imageViewUpload;
    private Button btnSubmit;
    private TextView tvDetectionResult, tvSuggestions;
    private Bitmap selectedImageBitmap;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        imageViewUpload = findViewById(R.id.imageViewUpload);
        btnSubmit = findViewById(R.id.btn_submit);
        tvDetectionResult = findViewById(R.id.tv_detection_result);
        tvSuggestions = findViewById(R.id.tv_suggestions);
        ImageView ivSearch1 = findViewById(R.id.iv_search1);

        // Open the ProfileActivity on button click
        ivSearch1.setOnClickListener(v -> {
            // Navigate to ProfileActivity
            Intent intent = new Intent(HomeActivity.this, ProfileActivity.class);
            startActivity(intent);
        });
        // Set up onClickListener for imageViewUpload to open gallery
        imageViewUpload.setOnClickListener(v -> openGallery());

        // Set up onClickListener for submit button to upload the image
        btnSubmit.setOnClickListener(v -> {
            if (selectedImageBitmap != null) {
                uploadImage(selectedImageBitmap);
            } else {
                Toast.makeText(HomeActivity.this, "Image could not be loaded", Toast.LENGTH_SHORT).show();
            }
        });
    }

    // Open the gallery to pick an image
    private void openGallery() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(intent, GALLERY_REQUEST_CODE);
    }

    // Handle the result of the gallery selection
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == GALLERY_REQUEST_CODE && resultCode == RESULT_OK && data != null) {
            Uri selectedImageUri = data.getData();
            try {
                selectedImageBitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), selectedImageUri);
                imageViewUpload.setImageBitmap(selectedImageBitmap); // Display the selected image in the ImageView
            } catch (IOException e) {
                e.printStackTrace();
                Toast.makeText(HomeActivity.this, "Failed to load image", Toast.LENGTH_SHORT).show();
            }
        }
    }

    // Upload image to Flask server
    private void uploadImage(Bitmap image) {
        OkHttpClient client = new OkHttpClient();

        // Convert Bitmap to File
        File imageFile = new File(getCacheDir(), "uploaded_image.jpg");
        try {
            FileOutputStream fos = new FileOutputStream(imageFile);
            image.compress(Bitmap.CompressFormat.JPEG, 100, fos);
            fos.flush();
            fos.close();
        } catch (IOException e) {
            e.printStackTrace();
            return;
        }

        // Create the request body
        MediaType MEDIA_TYPE = MediaType.parse("image/jpeg");
        RequestBody requestBody = new MultipartBody.Builder()
                .setType(MultipartBody.FORM)
                .addFormDataPart("file", imageFile.getName(),
                        RequestBody.create(MEDIA_TYPE, imageFile))
                .build();

        // Build the request
        Request request = new Request.Builder()
                .url(API_URL)
                .post(requestBody)
                .build();

        // Execute the request asynchronously
        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                runOnUiThread(() -> {
                    Toast.makeText(HomeActivity.this, "Request failed: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                });
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (response.isSuccessful()) {
                    String responseString = response.body().string();

                    // Parse the response and update UI
                    String detectionResult = parseResponse(responseString);
                    String diseaseName = getDiseaseName(Integer.parseInt(detectionResult));
                    String suggestion = getDiseaseSuggestion(diseaseName);

                    // Save results to SharedPreferences
                    saveResults(diseaseName, suggestion);

                    runOnUiThread(() -> {
                        tvDetectionResult.setText("Disease: " + diseaseName);
                        tvSuggestions.setText("Suggestion: " + (suggestion != null ? suggestion : "No suggestions available"));
                    });
                } else {
                    runOnUiThread(() -> Toast.makeText(HomeActivity.this, "Prediction failed", Toast.LENGTH_SHORT).show());
                }
            }
        });
    }

    // Save detection results to SharedPreferences
    private void saveResults(String disease, String suggestion) {
        SharedPreferences sharedPreferences = getSharedPreferences("PredictionResults", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();

        // Save disease and suggestion
        editor.putString("last_disease", disease);
        editor.putString("last_suggestion", suggestion);
        editor.apply();
    }

    // Parse the response from the server
    private String parseResponse(String responseString) {
        try {
            JSONObject jsonResponse = new JSONObject(responseString);
            return jsonResponse.getString("class_label"); // Assume the class label is in 'class_label'
        } catch (Exception e) {
            e.printStackTrace();
            return "Unknown";
        }
    }

    private String getDiseaseName(int classLabel) {
        switch (classLabel) {
            case 0: return "Aphid Test";
            case 1: return "Apple Scab";
            case 2: return "Bacterial Blight";
            case 3: return "Bacterial Spot";
            case 4: return "Bell Pepper Bacterial Spot";
            case 5: return "Bell Pepper Healthy";
            case 6: return "Black Spot";
            case 7: return "Black Rot";
            case 8: return "Black Rust Test";
            case 9: return "Blast";
            case 10: return "Blast Test";
            case 11: return "Brown Spot";
            case 12: return "Brown Rust";
            case 13: return "Brown Rust Test";
            case 14: return "Canker";
            case 15: return "Cherry Healthy";
            case 16: return "Citrus Healthy";
            case 17: return "Common Root Rot Test";
            case 18: return "Corn Common Rust";
            case 19: return "Corn Healthy";
            case 20: return "Early Blight";
            case 21: return "Esca (Black Measles)";
            case 22: return "Fusarium Head Blight Test";
            case 23: return "Grape Healthy";
            case 24: return "Greening";
            case 25: return "Haunglongbing (Greening)";
            case 26: return "Healthy";
            case 27: return "Healthy (2)";
            case 28: return "Healthy (3)";
            case 29: return "Healthy (4)";
            case 30: return "Healthy 1";
            case 31: return "Healthy T";
            case 32: return "Healthy Test";
            case 33: return "Late Blight";
            case 34: return "Leaf Blight (Isariopsis Leaf Spot)";
            case 35: return "Leaf Blight Test";
            case 36: return "Leaf Mold";
            case 37: return "Leaf Scorch";
            case 38: return "Mildew Test";
            case 39: return "Mite Test";
            case 40: return "Mosaic";
            case 41: return "Mosaic Virus";
            case 42: return "Normal Blast";
            case 43: return "Normal Rust";
            case 44: return "Northern Leaf Blight";
            case 45: return "Peach Bacterial Spot";
            case 46: return "Peach Healthy";
            case 47: return "Pepper Bell Bacterial Spot";
            case 48: return "Pepper Bell Healthy";
            case 49: return "Potato Early Blight";
            case 50: return "Potato Healthy";
            case 51: return "Potato Late Blight";
            case 52: return "Powdery Mildew";
            case 53: return "Raspberry Healthy";
            case 54: return "Red Rot";
            case 55: return "Rust";
            case 56: return "Septoria Leaf Spot";
            case 57: return "Septoria Test";
            case 58: return "Smut Test";
            case 59: return "Soybean Healthy";
            case 60: return "Spider Mites (Two-Spotted Spider Mite)";
            case 61: return "Squash Powdery Mildew";
            case 62: return "Stem Fly Test";
            case 63: return "Strawberry Healthy";
            case 64: return "Tan Spot Test";
            case 65: return "Target Spot";
            case 66: return "Tungro";
            case 67: return "Yellow";
            case 68: return "Yellow Leaf Curl Virus";
            case 69: return "Yellow Rust";
            case 70: return "Yellow Rust Test";
            default: return "Unknown Disease";
        }
    }

    // Get the suggestion based on the disease
    private String getDiseaseSuggestion(String diseaseName) {
        switch (diseaseName) {
            case "Aphid Test": return "Control aphids using insecticidal soap or neem oil. Spray thoroughly on the leaves' underside and repeat weekly until the infestation subsides. Encourage natural predators like ladybugs.";
            case "Apple Scab": return "To manage apple scab, prune and dispose of infected leaves and branches. Apply fungicides in early spring before symptoms appear and ensure adequate spacing for airflow.";
            case "Bacterial Blight": return "Use copper-based fungicides at the first sign of bacterial blight. Implement crop rotation and avoid overhead irrigation to reduce pathogen spread.";
            case "Bacterial Spot": return "Remove and destroy infected leaves to prevent bacterial spot. Use bactericides as a preventive measure and ensure proper spacing between plants for ventilation.";
            case "Bell Pepper Bacterial Spot": return "Apply copper-based fungicides and remove severely infected plants. Avoid working in wet fields to reduce the spread of the disease.";
            case "Bell Pepper Healthy": return "Your bell pepper plants are in excellent health. Maintain regular watering, fertilization, and pest monitoring to ensure continued growth.";
            case "Black Spot": return "Apply systemic fungicides to manage black spot and remove affected leaves. Regularly clean debris around plants to minimize fungal spores.";
            case "Black Rot": return "Prune infected parts immediately and apply fungicides. Enhance soil drainage and rotate crops to avoid pathogen buildup.";
            case "Black Rust Test": return "Plant rust-resistant varieties and apply fungicides early. Monitor fields regularly for early signs of infection and avoid overhead irrigation.";
            case "Blast": return "Apply broad-spectrum fungicides to manage blast disease. Ensure proper crop spacing and maintain good field hygiene to prevent further infections.";
            case "Blast Test": return "Remove infected plants to curb the spread of blast. Apply fungicides and avoid excessive nitrogen fertilization, which can promote disease development.";
            case "Brown Spot": return "Remove and dispose of infected leaves to control brown spot. Apply fungicides as needed and avoid splashing water onto leaves during irrigation.";
            case "Brown Rust": return "Control brown rust with fungicides and ensure proper airflow around plants. Practice crop rotation to minimize recurrence.";
            case "Brown Rust Test": return "Apply fungicides early to prevent rust from spreading. Maintain balanced soil nutrition and avoid excessive irrigation.";
            case "Canker": return "Prune infected branches and seal wounds with a fungicidal treatment. Disinfect tools between cuts to prevent further spread.";
            case "Cherry Healthy": return "Your cherry plants are healthy. Keep up with regular monitoring, proper fertilization, and pest control to maintain their health.";
            case "Citrus Healthy": return "Your citrus plants are thriving. Continue to monitor for pests and diseases, ensuring consistent watering and nutrient application.";
            case "Common Root Rot Test": return "Improve soil drainage to reduce root rot risks and apply appropriate fungicides. Rotate crops and avoid planting in infected soil.";
            case "Corn Common Rust": return "Apply fungicides designed for rust control and ensure proper crop rotation. Opt for rust-resistant corn varieties in future plantings.";
            case "Corn Healthy": return "Your corn plants are in excellent condition. Maintain good practices such as balanced fertilization and irrigation.";
            case "Early Blight": return "Remove and destroy infected leaves and apply fungicides targeted at early blight. Avoid overhead watering and improve air circulation around plants.";
            case "Esca (Black Measles)": return "Remove infected vines and apply fungicides during dormant seasons. Avoid excessive pruning injuries and maintain proper nutrition.";
            case "Fusarium Head Blight Test": return "Apply fungicides during flowering to manage Fusarium Head Blight. Avoid planting wheat in previously infected fields and use resistant varieties.";
            case "Grape Healthy": return "Your grapevines are in good health. Continue monitoring for pests or diseases and practice proper pruning and fertilization.";
            case "Greening": return "Apply systemic insecticides to control psyllid populations and remove infected plants. Use resistant rootstocks and practice integrated pest management.";
            case "Haunglongbing (Greening)": return "Promptly remove infected trees and apply insecticides to control psyllids. Monitor nearby trees regularly and consider introducing natural predators.";
            case "Healthy": return "Your plants are healthy. No treatment is required. Maintain good agricultural practices and keep monitoring for early signs of issues.";
            case "Healthy (2)": return "The plant shows no signs of disease. Continue routine care and monitoring to maintain its health.";
            case "Healthy (3)": return "Your plants are thriving. Ensure consistent watering and nutrient management.";
            case "Healthy (4)": return "No issues detected. Keep up regular maintenance to ensure ongoing plant vitality.";
            case "Healthy 1": return "The plant is in perfect condition. Continue to provide optimal growing conditions.";
            case "Healthy T": return "No treatment needed as the plant is healthy. Maintain proper care.";
            case "Healthy Test": return "Your plant is in great shape. Keep up good farming practices and regular inspections.";
            case "Late Blight": return "Remove and destroy infected plant material to limit late blight spread. Apply fungicides designed for blight control at regular intervals.";
            case "Leaf Blight (Isariopsis Leaf Spot)": return "Remove infected leaves and apply protective fungicides. Avoid overhead irrigation to minimize leaf wetness.";
            case "Leaf Blight Test": return "Cut off infected leaves and apply preventive fungicides. Ensure proper spacing for better airflow between plants.";
            case "Leaf Mold": return "Improve air circulation and remove infected leaves to control leaf mold. Apply fungicides and avoid high humidity conditions.";
            case "Leaf Scorch": return "Provide adequate irrigation during dry periods and remove severely scorched leaves to promote recovery.";
            case "Mildew Test": return "Remove infected leaves and use fungicides specific to mildew. Increase ventilation and reduce humidity levels around plants.";
            case "Mite Test": return "Use miticides to manage mite infestations. Enhance natural predator populations, such as predatory mites, for long-term control.";
            case "Mosaic": return "Destroy infected plants and control insect vectors like aphids. Use certified disease-free seeds for replanting.";
            case "Mosaic Virus": return "Remove infected plants to limit the spread. Control insect vectors through integrated pest management strategies.";
            case "Normal Blast": return "No action is required for normal blast. Keep monitoring plants for any signs of stress or disease.";
            case "Normal Rust": return "Your plants are free of rust issues. Continue regular monitoring and maintain good agricultural practices.";
            case "Northern Leaf Blight": return "Apply fungicides to manage Northern Leaf Blight. Remove infected leaves and ensure adequate spacing between plants.";
            case "Peach Bacterial Spot": return "Remove infected leaves and apply bactericides at regular intervals. Avoid overhead watering and use resistant peach varieties.";
            case "Peach Healthy": return "Your peach plants are in excellent health. Keep monitoring for early signs of disease and maintain good care practices.";
            case "Pepper Bell Bacterial Spot": return "Remove infected leaves and apply copper-based fungicides. Ensure proper irrigation and avoid water splashing on foliage.";
            case "Pepper Bell Healthy": return "Your bell pepper plants are healthy. Keep providing optimal growing conditions.";
            case "Potato Early Blight": return "Remove and destroy infected leaves and apply fungicides early. Avoid overhead watering to reduce humidity around the plant.";
            case "Potato Healthy": return "Your potato plants are healthy. Continue routine care and monitoring.";
            case "Potato Late Blight": return "Remove infected plant material and apply fungicides for late blight. Ensure proper spacing to reduce moisture buildup.";
            case "Powdery Mildew": return "Remove infected leaves and apply fungicides specifically for powdery mildew. Increase air circulation to reduce humidity.";
            case "Raspberry Healthy": return "Your raspberry plants are thriving. Ensure regular pruning and pest monitoring.";
            case "Red Rot": return "Apply fungicides and improve soil drainage to control red rot. Remove and destroy heavily infected plant material.";
            case "Rust": return "Apply rust-specific fungicides and select resistant varieties. Remove infected leaves to prevent further spread.";
            case "Septoria Leaf Spot": return "Remove infected leaves promptly and apply fungicides. Avoid overhead watering and ensure good air circulation.";
            case "Septoria Test": return "Remove infected parts of the plant and apply fungicides. Maintain proper hygiene around the plant area.";
            case "Smut Test": return "Remove and destroy infected plant parts. Apply protective fungicides and use disease-free seeds.";
            case "Soybean Healthy": return "Your soybean plants are healthy. Continue regular care and disease monitoring.";
            case "Spider Mites (Two-Spotted Spider Mite)": return "Apply miticides and spray plants with water to remove spider mites. Introduce predatory mites for biological control.";
            case "Squash Powdery Mildew": return "Apply fungicides and remove infected plant material. Ensure proper air circulation around squash plants.";
            case "Stem Fly Test": return "Use insecticides to control stem fly populations. Rotate crops and avoid continuous planting of susceptible crops.";
            case "Strawberry Healthy": return "Your strawberry plants are healthy. Maintain good care practices for sustained productivity.";
            case "Tan Spot Test": return "Apply fungicides to manage tan spot and rotate crops to reduce disease incidence.";
            case "Target Spot": return "Remove infected leaves and apply fungicides. Practice good crop sanitation to prevent the spread of the disease.";
            case "Tungro": return "Control insect vectors such as green leafhoppers using insecticides. Remove infected plants to prevent tungro spread.";
            case "Yellow": return "Improve soil drainage and remove yellowing parts to promote recovery. Maintain proper nutrient levels.";
            case "Yellow Leaf Curl Virus": return "Control insect vectors like whiteflies using integrated pest management. Remove infected plants to prevent further spread.";
            case "Yellow Rust": return "Apply fungicides early to manage yellow rust. Use rust-resistant plant varieties and maintain proper field hygiene.";
            case "Yellow Rust Test": return "Apply preventive fungicides and ensure proper airflow around plants. Select rust-resistant varieties for future planting.";
            default: return "No specific suggestions are available. Please consult a local agricultural expert for advice.";

        }
    }

}
